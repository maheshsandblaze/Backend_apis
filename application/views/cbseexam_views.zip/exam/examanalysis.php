<?php
$currency_symbol = $this->customlib->getSchoolCurrencyFormat();
?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-money"></i> <?php echo $this->lang->line('fees_collection'); ?>
        </h1>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div>


                        <div class="box-header ptbnull">
                            <h3 class="box-title titlefix"><i class="fa fa-users"></i> Examinations </h3>
                            <div class="btn-group pull-right">
                                <button onclick="window.history.back(); " class="btn btn-primary btn-xs"> <i class="fa fa-arrow-left"></i> Back</button> 
                            </div>
                        </div>

                        <div class="box-body">
                            <div class="col-md-2 hide-mobile">
                                <div class="box border0">
                                    <div class="box-header with-border">
                                        <h3 class="box-title"><?php echo $this->lang->line('cbse_exam'); ?></h3>
                                    </div>
                                    <ul class="tablists">
                                        <?php if ($this->rbac->hasPrivilege('cbse_exam', 'can_view')) { ?>
                                        <li class="<?php echo set_Submenu('exam/index'); ?>">
                                            <a class="<?php echo set_Submenu('exam/index'); ?>" href="<?php echo base_url(); ?>cbseexam/exam"><img src="<?php echo base_url('backend/images/sidebar/submenu/state_examination/1.png') ?>" alt="icon1" class="img-fluid" style="width:20px"> <?php echo $this->lang->line('exam'); ?></a>
                                        </li>     
                                        
                                        <?php
                                            }
                                            if ($this->rbac->hasPrivilege('cbse_exam_schedule', 'can_view')) {
                                                ?>
                                        <li class="<?php echo set_Submenu('exam/examtimetable'); ?>">
                                            <a class="<?php echo set_Submenu('exam/examtimetable'); ?>" href="<?php echo base_url(); ?>cbseexam/exam/examtimetable"><img src="<?php echo base_url('backend/images/sidebar/submenu/state_examination/2.png') ?>" alt="icon2" class="img-fluid" style="width:20px"> <?php echo $this->lang->line('exam_schedule'); ?></a>
                                        </li>
                            
                                        <?php
                                            }
                                            if ($this->rbac->hasPrivilege('cbse_exam_print_marksheet', 'can_view')) {
                                                ?>
                                        <li class="<?php echo set_Submenu('result/marksheet'); ?>">
                                            <a class="<?php echo set_Submenu('result/marksheet'); ?>" href="<?php echo base_url(); ?>cbseexam/result/marksheet"><img src="<?php echo base_url('backend/images/sidebar/submenu/state_examination/3.png') ?>" alt="icon3" class="img-fluid" style="width:20px"> <?php echo $this->lang->line('print_marksheet'); ?></a>
                                        </li> 
                                        
                                        <?php
                                            }
                                            if ($this->rbac->hasPrivilege('cbse_exam_grade', 'can_view')) {
                                                ?>
                                        <li class="<?php echo set_Submenu('grade/gradelist'); ?>">
                                            <a class="<?php echo set_Submenu('grade/gradelist'); ?>" href="<?php echo base_url(); ?>cbseexam/grade/gradelist"><img src="<?php echo base_url('backend/images/sidebar/submenu/state_examination/4.png') ?>" alt="icon4" class="img-fluid" style="width:20px"> <?php echo $this->lang->line('exam_grade'); ?></a>
                                        </li>
                                        <?php
                                            }
                                            if ($this->rbac->hasPrivilege('cbse_exam_assign_observation', 'can_view')) {
                                                ?>
                                        <li class="<?php echo set_Submenu('observation/assign'); ?>">
                                            <a class="<?php echo set_Submenu('observation/assign'); ?>" href="<?php echo base_url(); ?>cbseexam/observation/assign"><img src="<?php echo base_url('backend/images/sidebar/submenu/state_examination/5.png') ?>" alt="icon5" class="img-fluid" style="width:20px"> <?php echo $this->lang->line('assign_observation'); ?></a>
                                        </li>
                                        <?php
                                            }
                                            if ($this->rbac->hasPrivilege('cbse_exam_observation', 'can_view')) {
                                                ?>
                                        <li class="<?php echo set_Submenu('observation/index'); ?>">
                                            <a class="<?php echo set_Submenu('observation/index'); ?>" href="<?php echo base_url(); ?>cbseexam/observation"><img src="<?php echo base_url('backend/images/sidebar/submenu/state_examination/6.png') ?>" alt="icon6" class="img-fluid" style="width:20px"> <?php echo $this->lang->line('observation'); ?></a>
                                        </li>
                                        <?php
                                            }
                                            if ($this->rbac->hasPrivilege('cbse_exam_observation_parameter', 'can_view')) {
                                                ?>
                                        <li class="<?php echo set_Submenu('observationparameter/index'); ?>">
                                            <a class="<?php echo set_Submenu('observationparameter/index'); ?>" href="<?php echo base_url(); ?>cbseexam/observationparameter"><img src="<?php echo base_url('backend/images/sidebar/submenu/state_examination/7.png') ?>" alt="icon7" class="img-fluid" style="width:20px"> <?php echo $this->lang->line('observation_parameter'); ?></a>
                                        </li>
                                        <?php
                                            }
                                            if ($this->rbac->hasPrivilege('cbse_exam_assessment', 'can_view')) {
                                                ?>
                                        <li class="<?php echo set_Submenu('assessment/index'); ?>">
                                            <a class="<?php echo set_Submenu('assessment/index'); ?>" href="<?php echo base_url(); ?>cbseexam/assessment"><img src="<?php echo base_url('backend/images/sidebar/submenu/state_examination/8.png') ?>" alt="icon7" class="img-fluid" style="width:20px"> <?php echo $this->lang->line('assessment'); ?></a>
                                        </li>
                                        <?php
                                            }
                                            if ($this->rbac->hasPrivilege('cbse_exam_term', 'can_view')) {
                                                ?>
                                        <li class="<?php echo set_Submenu('term/index'); ?>">
                                            <a class="<?php echo set_Submenu('term/index'); ?>" href="<?php echo base_url(); ?>cbseexam/term"><img src="<?php echo base_url('backend/images/sidebar/submenu/state_examination/9.png') ?>" alt="icon7" class="img-fluid" style="width:20px"> <?php echo $this->lang->line('term'); ?></a>
                                        </li>
                                        <?php
                                            }
                                            if ($this->rbac->hasPrivilege('cbse_exam_template', 'can_view')) {
                                                ?>
                                        <li class="<?php echo set_Submenu('template/index'); ?>">
                                            <a class="<?php echo set_Submenu('template/index'); ?>" href="<?php echo base_url(); ?>cbseexam/template"><img src="<?php echo base_url('backend/images/sidebar/submenu/state_examination/4.png') ?>" alt="icon7" class="img-fluid" style="width:20px"> <?php echo $this->lang->line('template'); ?></a>
                                        </li> 
                                        <?php
                                            }
                                            if ($this->rbac->hasPrivilege('subject_marks_report', 'can_view')) {
                                                ?>
                                        <li class="<?php echo set_Submenu('report/index'); ?>">
                                            <a class="<?php echo set_Submenu('report/index'); ?>" href="<?php echo base_url(); ?>cbseexam/report/index"><img src="<?php echo base_url('backend/images/sidebar/submenu/state_examination/10.png') ?>" alt="icon7" class="img-fluid" style="width:20px"> <?php echo $this->lang->line('reports'); ?></a>
                                        </li>
                                        <?php
                                            }
                                            if ($this->rbac->hasPrivilege('cbse_exam_setting', 'can_view')) {
                                                ?>
                                        <li class="<?php echo set_Submenu('setting/index'); ?>">
                                            <a class="<?php echo set_Submenu('setting/index'); ?>" href="<?php echo base_url(); ?>cbseexam/setting/index"><img src="<?php echo base_url('backend/images/sidebar/submenu/state_examination/11.png') ?>" alt="icon7" class="img-fluid" style="width:20px"> <?php echo $this->lang->line('setting'); ?></a>
                                        </li>
                                        <?php
                                            }
                                        ?>
                                    </ul>
                                </div>
                            </div><!--./col-md-3-->
                            
                            <div class="col-lg-10 col-md-10 col-sm-12">
                                <div class="row">

                                    <div class="col-lg-4 col-md-4 col-sm-12">
                                        <div class="topprograssstart">
                                            <p class="mt5 clearfix font-16">FA1 Exam</p>
                                            <div class="box-header with-border">
                                                <div class="progress-group">
                                                    
                                                    <p class="mt5 clearfix">No.of Students Attempt<span class="pull-right">0</span></p>
                                                    <p class="mt5 clearfix">No.of Students Pass<span class="pull-right">0</span></p>
                                                    <p class="mt5 clearfix">No.of Students Fail<span class="pull-right">0</span></p>
                                                </div>
                                            </div>
                                        </div><!--./topprograssstart-->
                                    </div><!--./col-md-3-->

                            
                                    <div class="col-lg-4 col-md-4 col-sm-12">
                                        <div class="topprograssstart">
                                            <p class="mt5 clearfix font-16">FA2 Exam</p>
                                            <div class="box-header with-border">
                                                <div class="progress-group">
                                                    
                                                    <p class="mt5 clearfix">No.of Students Attempt<span class="pull-right">0</span></p>
                                                    <p class="mt5 clearfix">No.of Students Pass<span class="pull-right">0</span></p>
                                                    <p class="mt5 clearfix">No.of Students Fail<span class="pull-right">0</span></p>
                                                </div>
                                            </div>
                                        </div><!--./topprograssstart-->
                                    </div><!--./col-md-3-->

                                </div><!--./row-->
                            </div>
                        </div>
                       

                    </div>

                </div>

    </section>
</div>

<script>
    $(document).ready(function() {
        emptyDatatable('student-list', 'fees_data');

    });
</script>
<script type="text/javascript">
    $(document).ready(function() {

        var class_id = $('#class_id').val();
        var section_id = '<?php echo set_value('section_id', 0) ?>';
        getSectionByClass(class_id, section_id);
    });

    $(document).on('change', '#class_id', function(e) {
        $('#section_id').html("");
        var class_id = $(this).val();
        getSectionByClass(class_id, 0);
    });

    function getSectionByClass(class_id, section_id) {

        if (class_id != "") {
            $('#section_id').html("");
            var base_url = '<?php echo base_url() ?>';
            var div_data = '<option value=""><?php echo $this->lang->line('select'); ?></option>';
            $.ajax({
                type: "GET",
                url: base_url + "sections/getByClass",
                data: {
                    'class_id': class_id
                },
                dataType: "json",
                beforeSend: function() {
                    $('#section_id').addClass('dropdownloading');
                },
                success: function(data) {
                    $.each(data, function(i, obj) {
                        var sel = "";
                        if (section_id == obj.section_id) {
                            sel = "selected";
                        }
                        div_data += "<option value=" + obj.section_id + " " + sel + ">" + obj.section + "</option>";
                    });
                    $('#section_id').append(div_data);
                },
                complete: function() {
                    $('#section_id').removeClass('dropdownloading');
                }
            });
        }
    }
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("form.class_search_form button[type=submit]").click(function() {
            $("button[type=submit]", $(this).parents("form")).removeAttr("clicked");
            $(this).attr("clicked", "true");
        });


        $(document).on('submit', '.class_search_form', function(e) {
            e.preventDefault(); // avoid to execute the actual submit of the form.
            var $this = $("button[type=submit][clicked=true]");
            var form = $(this);
            var url = form.attr('action');
            var form_data = form.serializeArray();
            form_data.push({
                name: 'search_type',
                value: $this.attr('value')
            });
            $.ajax({
                url: url,
                type: "POST",
                dataType: 'JSON',
                data: form_data, // serializes the form's elements.
                beforeSend: function() {
                    $('[id^=error]').html("");
                    $this.button('loading');
                    resetFields($this.attr('name'));
                },
                success: function(response) { // your success handler
                console.log(response);
                    if (!response.status) {
                        $.each(response.error, function(key, value) {
                            $('#error_' + key).html(value);
                        });
                    } else {
                        initDatatable('student-list', 'studentfee/ajaxSearch', response.params, [], 100);
                    }
                },
                error: function() { // your error handler
                    $this.button('reset');
                },
                complete: function() {
                    $this.button('reset');
                }
            });

        });

    });

    function resetFields(search_type) {
        if (search_type == "keyword_search") {
            $('#class_id').prop('selectedIndex', 0);
            $('#section_id').find('option').not(':first').remove();
        } else if (search_type == "class_search") {

            $('#search_text').val("");
        }
    }
</script>